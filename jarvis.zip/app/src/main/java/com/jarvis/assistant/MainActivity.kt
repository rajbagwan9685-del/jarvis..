package com.jarvis.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {

    private fun startJarvis() {
        startForegroundService(Intent(this, JarvisService::class.java))
        Toast.makeText(this, "Jarvis chalu! Ab 'Jarvis' bolo.", Toast.LENGTH_LONG).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val p = getSharedPreferences("j", MODE_PRIVATE)
        val d = resources.displayMetrics.density
        val pad = (16 * d).toInt()
        val cyan = Color.parseColor("#19D3FF")
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
            setBackgroundColor(Color.parseColor("#050B14"))
        }
        fun tv(t: String, size: Float, color: Int = Color.parseColor("#D9F3FF")) = TextView(this).apply {
            text = t; textSize = size; setTextColor(color); setPadding(0, pad / 2, 0, pad / 2)
        }
        fun et(h: String, k: String) = EditText(this).apply {
            hint = h; setText(p.getString(k, "")); inputType = InputType.TYPE_CLASS_TEXT; setSingleLine(true)
            setTextColor(Color.WHITE); setHintTextColor(Color.parseColor("#6F93A8"))
        }
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }

        val size = (150 * d).toInt()
        col.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_launcher_foreground)
            layoutParams = LinearLayout.LayoutParams(size, size).apply { gravity = Gravity.CENTER_HORIZONTAL }
        })
        col.addView(tv("J A R V I S", 30f, cyan).apply { gravity = Gravity.CENTER })
        col.addView(tv("1) Apna naam likho.\n2) 'Display over other apps' permission do.\n3) 'Jarvis chalu karo' dabao. Phir kabhi bhi 'Jarvis' bolo.", 14f))

        val nameBox = et("Aapka naam (Jarvis isse bulayega)", "name")
        val claude = et("Claude API key (optional, dost jaisi baatein)", "claude")
        val friend = CheckBox(this).apply {
            text = "Dost mode: Jarvis khud baat kare (har 40-90 min)"
            setTextColor(Color.parseColor("#D9F3FF"))
            isChecked = p.getBoolean("friend", true)
        }
        col.addView(nameBox); col.addView(claude); col.addView(friend)

        col.addView(btn("Jarvis chalu karo") {
            p.edit().putString("name", nameBox.text.toString().trim())
                .putString("claude", claude.text.toString().trim())
                .putBoolean("friend", friend.isChecked).apply()
            val perms = mutableListOf(
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.CALL_PHONE,
                Manifest.permission.READ_CONTACTS
            )
            if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
            requestPermissions(perms.toTypedArray(), 1)
        })
        col.addView(btn("Display over other apps permission") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        col.addView(btn("Jarvis band karo") {
            stopService(Intent(this, JarvisService::class.java))
        })
        setContentView(ScrollView(this).apply { setBackgroundColor(Color.parseColor("#050B14")); addView(col) })
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startJarvis()
        else Toast.makeText(this, "Mic permission zaroori hai", Toast.LENGTH_LONG).show()
    }
}
