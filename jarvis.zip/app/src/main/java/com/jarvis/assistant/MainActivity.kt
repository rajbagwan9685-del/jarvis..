package com.jarvis.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.*

class MainActivity : Activity() {

    private fun startJarvis() {
        val i = Intent(this, JarvisService::class.java)
        startForegroundService(i)
        Toast.makeText(this, "Jarvis chalu! Ab 'Jarvis' bolo.", Toast.LENGTH_LONG).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val p = getSharedPreferences("j", MODE_PRIVATE)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }
        fun tv(t: String, size: Float) = TextView(this).apply {
            text = t; textSize = size; setPadding(0, pad / 2, 0, pad / 2)
        }
        fun et(h: String, k: String) = EditText(this).apply {
            hint = h; setText(p.getString(k, "")); inputType = InputType.TYPE_CLASS_TEXT; setSingleLine(true)
        }
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }

        val pico = et("Picovoice AccessKey (zaroori)", "pico")
        val claude = et("Claude API key (optional)", "claude")

        col.addView(tv("JARVIS", 30f))
        col.addView(tv("1) Picovoice AccessKey daalo (console.picovoice.ai se free).\n2) 'Display over other apps' permission do.\n3) 'Jarvis chalu karo' dabao, phir kabhi bhi 'Jarvis' bolo.", 15f))
        col.addView(pico)
        col.addView(claude)
        col.addView(btn("Jarvis chalu karo") {
            p.edit().putString("pico", pico.text.toString().trim())
                .putString("claude", claude.text.toString().trim()).apply()
            val perms = mutableListOf(
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.CALL_PHONE,
                Manifest.permission.READ_CONTACTS
            )
            if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
            requestPermissions(perms.toTypedArray(), 1)
        })
        col.addView(btn("Display over other apps permission") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        col.addView(btn("Jarvis band karo") {
            stopService(Intent(this, JarvisService::class.java))
        })
        setContentView(ScrollView(this).apply { addView(col) })
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startJarvis()
        else Toast.makeText(this, "Mic permission zaroori hai", Toast.LENGTH_LONG).show()
    }
}
