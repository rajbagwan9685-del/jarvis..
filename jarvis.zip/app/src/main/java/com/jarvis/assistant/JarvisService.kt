package com.jarvis.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.widget.Toast
import java.util.Calendar
import java.util.Locale
import kotlin.random.Random

class JarvisService : Service(), TextToSpeech.OnInitListener {

    private val main = Handler(Looper.getMainLooper())
    private var sr: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var running = true
    private var speaking = false
    private var working = false
    private var expectReply = false
    private var mode = 0 // 0 = "Jarvis" ka intezaar, 1 = command, 2 = dost ka jawab
    private lateinit var cmd: Commands

    private val wakeRe = Regex("jar[vw]i[sc]h?|जा?र्?व[ीि][सशज़]")
    private val fillers = setOf("hey", "hi", "ok", "okay", "ए", "हे", "अरे", "ओके", "हेलो", "hello")

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("jarvis", "Jarvis", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel("jarvis_chat", "Jarvis baatein", NotificationManager.IMPORTANCE_DEFAULT))
        val n = Notification.Builder(this, "jarvis")
            .setContentTitle("Jarvis sun raha hai")
            .setContentText("\"Jarvis\" bolkar command do")
            .setSmallIcon(R.drawable.ic_stat)
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
        cmd = Commands(this)
        tts = TextToSpeech(this, this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale("hi", "IN")
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) {}
                override fun onDone(id: String?) { main.post { afterSpeak() } }
                @Deprecated("deprecated")
                override fun onError(id: String?) { main.post { afterSpeak() } }
            })
            ttsReady = true
        }
        scheduleChat()
        say(cmd.greeting(), false)
    }

    private fun afterSpeak() {
        speaking = false
        if (expectReply) { expectReply = false; mode = 2 } else mode = 0
        startListening(250)
    }

    private fun toast(t: String) = main.post { Toast.makeText(this, t, Toast.LENGTH_LONG).show() }

    private fun startListening(delay: Long) {
        main.postDelayed({ if (running && !speaking && !working) listen() }, delay)
    }

    private fun listen() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { toast("Speech service nahi mili (Google app chahiye)"); return }
        try { sr?.destroy() } catch (e: Exception) { }
        sr = SpeechRecognizer.createSpeechRecognizer(this)
        sr?.setRecognitionListener(object : RecognitionListener {
            override fun onResults(r: Bundle?) {
                onHeard(r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: arrayListOf())
            }
            override fun onError(error: Int) {
                if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) { toast("Mic permission do"); return }
                mode = 0
                val d = when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> 150L
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> 1500L
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT, SpeechRecognizer.ERROR_SERVER -> 4000L
                    else -> 1000L
                }
                startListening(d)
            }
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(p: Bundle?) {}
            override fun onEvent(t: Int, p: Bundle?) {}
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
            .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        sr?.startListening(i)
    }

    private fun onHeard(list: List<String>) {
        val first = list.firstOrNull()?.trim() ?: ""
        when (mode) {
            0 -> {
                val hit = list.map { it.lowercase(Locale.ROOT) }.firstOrNull { wakeRe.containsMatchIn(it) }
                if (hit == null) { startListening(100); return }
                val rest = hit.replace(wakeRe, " ").split(Regex("[\\s,.!?]+"))
                    .filter { it.isNotBlank() && it !in fillers }.joinToString(" ")
                if (rest.length > 1) process(rest, false)
                else {
                    mode = 1
                    try { ToneGenerator(AudioManager.STREAM_MUSIC, 80).startTone(ToneGenerator.TONE_PROP_BEEP, 150) } catch (e: Exception) { }
                    startListening(300)
                }
            }
            1 -> if (first.isBlank()) { mode = 0; startListening(100) } else process(first, false)
            else -> if (first.isBlank()) { mode = 0; startListening(100) } else process(first, true)
        }
    }

    private fun process(text: String, convo: Boolean) {
        mode = 0
        working = true
        Thread {
            val reply = try { if (convo) cmd.chat(text) else cmd.run(text) } catch (e: Exception) { "कुछ गड़बड़ हो गई" }
            main.post { working = false; say(reply, false) }
        }.start()
    }

    private fun say(t: String, reply: Boolean) {
        if (!ttsReady || t.isBlank()) { startListening(200); return }
        try { sr?.cancel() } catch (e: Exception) { }
        speaking = true
        expectReply = reply
        tts?.speak(t, TextToSpeech.QUEUE_FLUSH, null, "u")
    }

    // ---- Dost mode: Jarvis khud baat shuru karta hai ----
    private val chatRun = Runnable {
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        if (h in 7..22 && !speaking && !working) {
            working = true
            Thread {
                val line = try { cmd.friendLine() } catch (e: Exception) { "" }
                main.post {
                    working = false
                    if (line.isNotBlank()) { notifyChat(line); say(line, true) }
                }
            }.start()
        }
        scheduleChat()
    }

    private fun scheduleChat() {
        main.removeCallbacks(chatRun)
        if (!getSharedPreferences("j", MODE_PRIVATE).getBoolean("friend", true)) return
        main.postDelayed(chatRun, (40 + Random.nextInt(50)) * 60_000L)
    }

    private fun notifyChat(line: String) {
        val n = Notification.Builder(this, "jarvis_chat")
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("Jarvis")
            .setContentText(line)
            .setStyle(Notification.BigTextStyle().bigText(line))
            .setAutoCancel(true)
            .build()
        getSystemService(NotificationManager::class.java).notify(2, n)
    }

    override fun onDestroy() {
        running = false
        main.removeCallbacksAndMessages(null)
        try { sr?.destroy() } catch (e: Exception) { }
        tts?.shutdown()
        super.onDestroy()
    }
}
