package com.jarvis.assistant

import ai.picovoice.porcupine.Porcupine
import ai.picovoice.porcupine.PorcupineManager
import ai.picovoice.porcupine.PorcupineManagerCallback
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.widget.Toast
import java.util.Locale

class JarvisService : Service(), TextToSpeech.OnInitListener {

    private val main = Handler(Looper.getMainLooper())
    private var wake: PorcupineManager? = null
    private var sr: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var failed = false
    private lateinit var cmd: Commands

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("jarvis", "Jarvis", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "jarvis")
            .setContentTitle("Jarvis sun raha hai")
            .setContentText("\"Jarvis\" bolkar command do")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
        cmd = Commands(this)
        tts = TextToSpeech(this, this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale("hi", "IN")
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) {}
                override fun onDone(id: String?) { main.post { startWake() } }
                @Deprecated("deprecated")
                override fun onError(id: String?) { main.post { startWake() } }
            })
            ttsReady = true
        }
        main.post { startWake() }
    }

    private fun toast(t: String) = main.post { Toast.makeText(this, t, Toast.LENGTH_LONG).show() }

    private fun startWake() {
        if (wake != null || failed) return
        val key = getSharedPreferences("j", MODE_PRIVATE).getString("pico", "") ?: ""
        if (key.isBlank()) { failed = true; toast("Picovoice AccessKey daalo"); return }
        try {
            wake = PorcupineManager.Builder()
                .setAccessKey(key)
                .setKeyword(Porcupine.BuiltInKeyword.JARVIS)
                .setSensitivity(0.7f)
                .build(this, PorcupineManagerCallback { onWake() })
            wake?.start()
        } catch (e: Exception) {
            wake = null; failed = true
            toast("Wake word nahi chala: " + e.message)
        }
    }

    private fun stopWake() {
        try { wake?.stop(); wake?.delete() } catch (e: Exception) { }
        wake = null
    }

    private fun onWake() {
        main.post {
            stopWake()
            try { ToneGenerator(AudioManager.STREAM_MUSIC, 80).startTone(ToneGenerator.TONE_PROP_BEEP, 150) } catch (e: Exception) { }
            main.postDelayed({ listen() }, 350)
        }
    }

    private fun listen() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { toast("Speech service nahi mili"); startWake(); return }
        sr?.destroy()
        sr = SpeechRecognizer.createSpeechRecognizer(this)
        sr?.setRecognitionListener(object : RecognitionListener {
            override fun onResults(r: Bundle?) {
                val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (t.isNullOrBlank()) startWake() else handle(t)
            }
            override fun onError(error: Int) { startWake() }
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(p: Bundle?) {}
            override fun onEvent(t: Int, p: Bundle?) {}
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
        sr?.startListening(i)
    }

    private fun handle(text: String) {
        Thread {
            val reply = try { cmd.run(text) } catch (e: Exception) { "कुछ गड़बड़ हो गई" }
            main.post { say(reply) }
        }.start()
    }

    private fun say(t: String) {
        if (ttsReady && t.isNotBlank()) tts?.speak(t, TextToSpeech.QUEUE_FLUSH, null, "u") else startWake()
    }

    override fun onDestroy() {
        stopWake()
        sr?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }
}
