package com.jarvis.assistant

import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.ContactsContract
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class Commands(private val c: Context) {

    private val prefs get() = c.getSharedPreferences("j", Context.MODE_PRIVATE)
    private fun key(): String = prefs.getString("claude", "") ?: ""
    private fun userName(): String {
        val n = prefs.getString("name", "") ?: ""
        return if (n.isBlank()) "दोस्त" else n
    }

    private var lastLine = ""
    private val hist = ArrayList<Pair<String, String>>()

    private fun has(s: String, vararg k: String) = k.any { s.contains(it) }

    private fun clean(s: String, drop: Set<String>) =
        s.split(Regex("\\s+")).filter { it.isNotBlank() && it !in drop }.joinToString(" ")

    private fun launch(i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { c.startActivity(i) } catch (e: Exception) { }
    }

    private val common = setOf("jarvis", "जार्विस", "जर्विस", "please", "karo", "करो", "kar", "कर", "do", "दो", "ko", "को", "ka", "का", "ki", "की")

    private val aliases = mapOf(
        "यूट्यूब" to "youtube", "यूटयूब" to "youtube", "व्हाट्सएप" to "whatsapp", "व्हाट्सऐप" to "whatsapp",
        "वाट्सएप" to "whatsapp", "इंस्टाग्राम" to "instagram", "क्रोम" to "chrome", "कैमरा" to "camera",
        "गैलरी" to "gallery", "मैप्स" to "maps", "जीमेल" to "gmail", "फेसबुक" to "facebook",
        "सेटिंग" to "settings", "सेटिंग्स" to "settings", "कैलकुलेटर" to "calculator"
    )

    private fun openApp(nameIn: String): Boolean {
        val name = aliases[nameIn] ?: nameIn
        if (name.isBlank()) return false
        val pm = c.packageManager
        val m = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val app = pm.queryIntentActivities(m, 0)
            .firstOrNull { it.loadLabel(pm).toString().lowercase().contains(name) } ?: return false
        val i = pm.getLaunchIntentForPackage(app.activityInfo.packageName) ?: return false
        launch(i)
        return true
    }

    private fun findNumber(q: String): String? {
        val digits = q.filter { it.isDigit() || it == '+' }
        if (digits.length >= 6) return digits
        if (q.isBlank()) return null
        try {
            c.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
                arrayOf("%$q%"), null
            )?.use { if (it.moveToFirst()) return it.getString(0) }
        } catch (e: Exception) { }
        return null
    }

    // ---------- Normal commands ----------
    fun run(raw: String): String {
        val r = tryLocal(raw)
        if (r != null) return r
        if (key().isNotBlank()) return askClaude(raw, null)
        launch(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(raw))))
        return "गूगल पर ढूंढ रहा हूँ"
    }

    // Dost ke jawab ke liye
    fun chat(text: String): String {
        val r = tryLocal(text)
        if (r != null) return r
        val ctx = lastLine
        lastLine = ""
        if (key().isNotBlank()) return askClaude(text, ctx)
        return listOf(
            "अच्छा! सुनकर अच्छा लगा।",
            "हम्म, समझ गया। और बताओ?",
            "ठीक है ${userName()}, मैं यहीं हूँ। कुछ भी चाहिए तो बस जार्विस बोलना।",
            "वाह! मज़ा आ गया।"
        ).random()
    }

    fun greeting(): String = "नमस्ते ${userName()}! मैं जार्विस, चालू हो गया हूँ। बस जार्विस बोलना।"

    private fun canned(h: Int): List<String> {
        val n = userName()
        return when {
            h < 12 -> listOf("गुड मॉर्निंग $n! उठ गए? चाय नाश्ता हुआ?", "सुबह सुबह कैसा चल रहा है $n? आज का क्या प्लान है?")
            h < 16 -> listOf("$n, काम कैसा चल रहा है? खाना खाया कि नहीं?", "थोड़ा पानी पी लो $n, और बताओ दिन कैसा जा रहा है?")
            h < 20 -> listOf("शाम हो गई $n, थोड़ा ब्रेक ले लो। चाय पीने का मन है?", "आज का दिन कैसा रहा $n?")
            else -> listOf("$n, रात हो गई। खाना खा लिया? कल का कुछ प्लान है?", "अब थोड़ा आराम कर लो $n, बहुत काम हो गया।")
        }
    }

    // Jarvis khud baat shuru karta hai
    fun friendLine(): String {
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        if (key().isNotBlank()) {
            val period = when { h < 12 -> "सुबह"; h < 16 -> "दोपहर"; h < 20 -> "शाम"; else -> "रात" }
            val topic = listOf("हाल-चाल", "खाना-पीना", "आज का काम या प्लान", "कोई मज़ेदार बात", "थोड़ा आराम और पानी पीने की याद").random()
            val msgs = JSONArray().put(JSONObject().put("role", "user")
                .put("content", "अभी $period का समय है। मुझसे दोस्त की तरह अपनी तरफ से बात शुरू करो, विषय: $topic। 1-2 छोटे वाक्य, और आख़िर में एक छोटा सा सवाल।"))
            val r = post(key(), system(), msgs)
            if (r != null) { lastLine = r; return r }
        }
        val line = canned(h).random()
        lastLine = line
        return line
    }

    private fun tryLocal(raw: String): String? {
        val s = raw.lowercase(Locale.ROOT).trim()

        // Timer
        val tm = Regex("(\\d+)\\s*(second|sec|सेकंड|सेकेंड|minute|min|मिनट|hour|ghanta|घंटा|घंटे)").find(s)
        if (tm != null && has(s, "timer", "टाइमर")) {
            val n = tm.groupValues[1].toInt()
            val u = tm.groupValues[2]
            val secs = if (u.startsWith("sec") || u.startsWith("सेक")) n else if (u.startsWith("min") || u.startsWith("मिन")) n * 60 else n * 3600
            launch(Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, secs).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
            return "ठीक है, $n $u का टाइमर चालू"
        }

        // Alarm
        if (has(s, "alarm", "अलार्म")) {
            val m = Regex("(\\d{1,2})(?::(\\d{2}))?").find(s)
            if (m != null) {
                var h = m.groupValues[1].toInt()
                val min = m.groupValues[2].ifEmpty { "0" }.toInt()
                if (has(s, "shaam", "शाम", "raat", "रात", "pm", "dopahar", "दोपहर") && h < 12) h += 12
                if (h in 0..23 && min in 0..59) {
                    launch(Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, h)
                        .putExtra(AlarmClock.EXTRA_MINUTES, min).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
                    return "अलार्म $h:" + "%02d".format(min) + " बजे के लिए सेट"
                }
            }
            return "अलार्म का समय समझ नहीं आया"
        }

        // Torch
        if (has(s, "torch", "टॉर्च", "टार्च", "flashlight", "फ्लैशलाइट")) {
            val on = !has(s, "band", "बंद", "बन्द", "off")
            return try {
                val cm = c.getSystemService(Context.CAMERA_SERVICE) as CameraManager
                cm.setTorchMode(cm.cameraIdList[0], on)
                if (on) "टॉर्च चालू" else "टॉर्च बंद"
            } catch (e: Exception) { "टॉर्च नहीं चली" }
        }

        // Volume
        if (has(s, "volume", "वॉल्यूम", "आवाज")) {
            val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val up = has(s, "badha", "बढ़ा", "बढा", "up", "zyada", "ज्यादा", "तेज")
            am.adjustStreamVolume(AudioManager.STREAM_MUSIC,
                if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
            return "ठीक है"
        }

        // SMS: "message Ravi ko kahan ho"
        if (has(s, "sms", "message", "मैसेज", "मेसेज")) {
            val m = Regex("(?:sms|message|मैसेज|मेसेज)\\s+(?:to\\s+)?(.+?)\\s+(?:ko|को)\\s+(.+)").find(s)
            if (m != null) {
                val n = findNumber(m.groupValues[1].trim()) ?: return "नंबर नहीं मिला"
                launch(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(n))).putExtra("sms_body", m.groupValues[2].trim()))
                return "मैसेज तैयार है, भेज दीजिए"
            }
            return "ऐसे बोलिए: मैसेज रवि को कहाँ हो"
        }

        // Call
        if (has(s, "call", "कॉल", "फोन", "phone")) {
            val q = clean(s, common + setOf("call", "कॉल", "phone", "फोन", "lagao", "लगाओ", "laga", "लगा"))
            val n = findNumber(q) ?: return "$q का नंबर नहीं मिला"
            launch(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(n))))
            return "कॉल लगा रहा हूँ"
        }

        // Open app
        if (has(s, "open", "kholo", "khol", "खोलो", "खोल", "ओपन", "chalu", "चालू")) {
            val name = clean(s, common + setOf("open", "ओपन", "kholo", "khol", "खोलो", "खोल", "chalu", "चालू", "app", "ऐप", "एप"))
            return if (openApp(name)) "खोल रहा हूँ" else "ऐप नहीं मिला"
        }

        // Play on YouTube
        if (has(s, "play", "bajao", "बजाओ", "चलाओ", "gaana", "गाना", "सुनाओ")) {
            val q = clean(s, common + setOf("play", "bajao", "बजाओ", "chalao", "चलाओ", "gaana", "गाना", "sunao", "सुनाओ", "youtube", "यूट्यूब", "par", "पर"))
            launch(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q))))
            return "यूट्यूब पर चला रहा हूँ"
        }

        // Search
        if (has(s, "search", "dhundo", "ढूंढो", "ढूँढो", "सर्च", "google")) {
            val q = clean(s, common + setOf("search", "सर्च", "dhundo", "ढूंढो", "ढूँढो", "google", "गूगल", "par", "पर"))
            launch(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))))
            return "गूगल पर ढूंढ रहा हूँ"
        }

        // Time / date
        if (has(s, "kitne baje", "samay", "time", "समय", "टाइम", "कितने बजे"))
            return "अभी " + SimpleDateFormat("h:mm a", Locale.ENGLISH).format(Date()) + " बजे हैं"
        if (has(s, "tarikh", "date", "तारीख", "कौन सा दिन"))
            return "आज " + SimpleDateFormat("EEEE, d MMMM yyyy", Locale("hi", "IN")).format(Date()) + " है"

        return null
    }

    // ---------- AI (optional Claude key) ----------
    private fun system(): String =
        "तुम JARVIS हो, ${userName()} के पक्के दोस्त और पर्सनल असिस्टेंट। दोस्त की तरह अपनेपन से बात करो, थोड़ा मज़ाकिया रहो। " +
        "हमेशा देवनागरी हिंदी में 1-3 छोटे वाक्य बोलो (अगर यूज़र English में बोले तो English में)। बिना markdown और बिना emoji।"

    private fun post(k: String, system: String, msgs: JSONArray): String? = try {
        val conn = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.connectTimeout = 15000
        conn.readTimeout = 30000
        conn.doOutput = true
        conn.setRequestProperty("x-api-key", k)
        conn.setRequestProperty("anthropic-version", "2023-06-01")
        conn.setRequestProperty("content-type", "application/json")
        val body = JSONObject()
            .put("model", "claude-haiku-4-5-20251001")
            .put("max_tokens", 300)
            .put("system", system)
            .put("messages", msgs)
        conn.outputStream.use { it.write(body.toString().toByteArray()) }
        val ok = conn.responseCode in 200..299
        val txt = (if (ok) conn.inputStream else conn.errorStream).bufferedReader().readText()
        if (ok) JSONObject(txt).getJSONArray("content").getJSONObject(0).getString("text") else null
    } catch (e: Exception) { null }

    private fun askClaude(q: String, ctx: String?): String {
        val msgs = JSONArray()
        for ((u, a) in hist) {
            msgs.put(JSONObject().put("role", "user").put("content", u))
            msgs.put(JSONObject().put("role", "assistant").put("content", a))
        }
        val content = if (!ctx.isNullOrBlank()) "(तुमने अभी मुझसे कहा था: \"$ctx\")\n$q" else q
        msgs.put(JSONObject().put("role", "user").put("content", content))
        val r = post(key(), system(), msgs) ?: return "AI से जवाब नहीं आया, इंटरनेट या API key जाँचिए"
        hist.add(Pair(content, r))
        while (hist.size > 8) hist.removeAt(0)
        return r
    }
}
